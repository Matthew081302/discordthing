export * from './socketstructs/channel';
export * from './socketstructs/generic';
export * from './socketstructs/guild';
export * from './socketstructs/message';
export * from './socketstructs/user';
