/**
 * BetterDiscord Button Component
 * Copyright (c) 2015-present Jiiks/JsSucks - https://github.com/Jiiks / https://github.com/JsSucks
 * All rights reserved.
 * https://betterdiscord.net
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
*/

<template>
    <div class="bd-button" :class="[{'bd-disabled': disabled}, {'bd-err': type === 'err'}]" @click="!disabled && !loading ? $emit('click', $event) : null">
        <div v-if="loading" class="bd-spinner7"></div>
        <slot v-else />
    </div>
</template>

<script>
    export default {
        props: ['loading', 'disabled', 'type']
    }
</script>
