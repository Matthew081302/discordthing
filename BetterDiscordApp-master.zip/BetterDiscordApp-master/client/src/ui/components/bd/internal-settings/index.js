export { default as WindowPreferences } from './WindowPreferences.vue';
