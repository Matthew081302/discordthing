### node-keytar bindings

Copy this directory to `node_modules/keytar/build/Release/keytar.node` to use.
