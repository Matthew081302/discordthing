<template>
    <div id="app">
        Installer
    </div>
</template>

<script>
    export default {}
</script>
