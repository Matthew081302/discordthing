module.exports = class {

    constructor() {
    }

    get foo() {
        return 'Bar';
    }

    add(i1, i2) {
        return i1 + i2;
    }

}
